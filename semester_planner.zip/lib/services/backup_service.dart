import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sqflite/sqflite.dart';
import '../core/constants/app_constants.dart';
import '../data/database/database_helper.dart';

class BackupService {
  static Future<String> exportBackup() async {
    await Permission.storage.request();
    final db = await DatabaseHelper.instance.database;

    final plans = await db.query('plans');
    final units = await db.query('units');
    final lessons = await db.query('lessons');
    final weeklyRows = await db.query('weekly_rows');

    final backupData = {
      'version': 1,
      'timestamp': DateTime.now().toIso8601String(),
      'plans': plans,
      'units': units,
      'lessons': lessons,
      'weekly_rows': weeklyRows,
    };

    final jsonString = jsonEncode(backupData);
    final directory = await getExternalStorageDirectory();
    final folderPath = '${directory!.path}/${AppConstants.folderName}';
    await Directory(folderPath).create(recursive: true);

    final fileName = 'backup_${DateTime.now().millisecondsSinceEpoch}${AppConstants.backupExtension}';
    final filePath = '$folderPath/$fileName';
    final file = File(filePath);
    await file.writeAsString(jsonString);

    return filePath;
  }

  static Future<void> importBackup(String filePath) async {
    final file = File(filePath);
    if (!await file.exists()) throw Exception('الملف غير موجود');

    final jsonString = await file.readAsString();
    final backupData = jsonDecode(jsonString) as Map<String, dynamic>;

    final db = await DatabaseHelper.instance.database;

    await db.transaction((txn) async {
      // Clear existing data
      await txn.delete('weekly_rows');
      await txn.delete('lessons');
      await txn.delete('units');
      await txn.delete('plans');

      // Restore plans
      for (final plan in backupData['plans'] as List) {
        await txn.insert('plans', plan as Map<String, dynamic>);
      }

      // Restore units
      for (final unit in backupData['units'] as List) {
        await txn.insert('units', unit as Map<String, dynamic>);
      }

      // Restore lessons
      for (final lesson in backupData['lessons'] as List) {
        await txn.insert('lessons', lesson as Map<String, dynamic>);
      }

      // Restore weekly rows
      for (final row in backupData['weekly_rows'] as List) {
        await txn.insert('weekly_rows', row as Map<String, dynamic>);
      }
    });
  }
}
