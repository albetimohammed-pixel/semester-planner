import 'dart:io';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import '../core/constants/app_constants.dart';
import '../data/models/plan_model.dart';
import '../data/models/weekly_row_model.dart';
import '../domain/entities/plan_entity.dart';

class PdfService {
  static Future<String> exportPlan(PlanEntity planEntity) async {
    final pdf = pw.Document();
    final plan = planEntity.plan;
    final rows = planEntity.weeklyRows;

    // Load Arabic font
    final arabicFont = pw.Font.ttf(
      await File('assets/fonts/Cairo-Regular.ttf').readAsBytes().then((bytes) => bytes.buffer.asByteData()),
    );
    final arabicFontBold = pw.Font.ttf(
      await File('assets/fonts/Cairo-Bold.ttf').readAsBytes().then((bytes) => bytes.buffer.asByteData()),
    );

    final textStyle = pw.TextStyle(font: arabicFont, fontSize: 10);
    final headerStyle = pw.TextStyle(font: arabicFontBold, fontSize: 12, color: PdfColors.white);
    final titleStyle = pw.TextStyle(font: arabicFontBold, fontSize: 14);
    final footerStyle = pw.TextStyle(font: arabicFont, fontSize: 9, color: PdfColors.grey700);

    // Build pages (max 8 rows per page)
    const int rowsPerPage = 8;
    final int totalPages = (rows.length / rowsPerPage).ceil();

    for (int pageIndex = 0; pageIndex < totalPages; pageIndex++) {
      final start = pageIndex * rowsPerPage;
      final end = (start + rowsPerPage).clamp(0, rows.length);
      final pageRows = rows.sublist(start, end);

      pdf.addPage(
        pw.Page(
          pageFormat: PdfPageFormat.a4,
          margin: const pw.EdgeInsets.all(24),
          build: (context) {
            return pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.center,
              children: [
                // Header
                _buildHeader(plan, titleStyle, textStyle),
                pw.SizedBox(height: 12),
                // Table
                pw.Expanded(
                  child: _buildTable(pageRows, headerStyle, textStyle),
                ),
                pw.SizedBox(height: 8),
                // Footer
                _buildFooter(pageIndex + 1, totalPages, footerStyle),
              ],
            );
          },
        ),
      );
    }

    // Save
    await Permission.storage.request();
    final directory = await getExternalStorageDirectory();
    final folderPath = '${directory!.path}/${AppConstants.folderName}';
    await Directory(folderPath).create(recursive: true);

    final fileName = AppUtils.generateFileName(
      plan.subject,
      plan.grade,
      plan.semester,
    );
    final filePath = '$folderPath/$fileName';
    final file = File(filePath);
    await file.writeAsBytes(await pdf.save());

    return filePath;
  }

  static pw.Widget _buildHeader(PlanModel plan, pw.TextStyle titleStyle, pw.TextStyle textStyle) {
    return pw.Container(
      width: double.infinity,
      padding: const pw.EdgeInsets.all(12),
      decoration: pw.BoxDecoration(
        border: pw.Border.all(width: 1.5),
        borderRadius: pw.BorderRadius.circular(4),
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.center,
        children: [
          pw.Text('الجمهورية اليمنية', style: titleStyle),
          pw.Text('وزارة التربية والتعليم', style: titleStyle),
          pw.SizedBox(height: 8),
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceEvenly,
            children: [
              pw.Text('المدرسة: ${plan.schoolName}', style: textStyle),
              pw.Text('المادة: ${plan.subject}', style: textStyle),
            ],
          ),
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceEvenly,
            children: [
              pw.Text('الصف: ${plan.grade}', style: textStyle),
              pw.Text('الفصل: ${plan.semester}', style: textStyle),
            ],
          ),
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceEvenly,
            children: [
              pw.Text('العام الدراسي: ${plan.academicYear}', style: textStyle),
              pw.Text('المعلم: ${plan.teacherName}', style: textStyle),
            ],
          ),
        ],
      ),
    );
  }

  static pw.Widget _buildTable(List<WeeklyRowModel> rows, pw.TextStyle headerStyle, pw.TextStyle textStyle) {
    return pw.Table(
      border: pw.TableBorder.all(width: 1),
      columnWidths: {
        0: const pw.FlexColumnWidth(1.2),   // الشهر
        1: const pw.FlexColumnWidth(1.5),   // الفترة
        2: const pw.FlexColumnWidth(1),     // الأسبوع
        3: const pw.FlexColumnWidth(0.8),   // الحصص
        4: const pw.FlexColumnWidth(2.5),   // المحتوى
        5: const pw.FlexColumnWidth(2.5),   // الأهداف
        6: const pw.FlexColumnWidth(2),     // الطرق والوسائل
        7: const pw.FlexColumnWidth(2),     // الأنشطة
        8: const pw.FlexColumnWidth(1.5),   // التقويم
      },
      children: [
        // Header row
        pw.TableRow(
          decoration: const pw.BoxDecoration(color: PdfColors.blue800),
          children: [
            _tableCell('الشهر', headerStyle, isHeader: true),
            _tableCell('الفترة', headerStyle, isHeader: true),
            _tableCell('الأسبوع', headerStyle, isHeader: true),
            _tableCell('الحصص', headerStyle, isHeader: true),
            _tableCell('المحتوى', headerStyle, isHeader: true),
            _tableCell('الأهداف', headerStyle, isHeader: true),
            _tableCell('الطرق والوسائل', headerStyle, isHeader: true),
            _tableCell('الأنشطة', headerStyle, isHeader: true),
            _tableCell('التقويم', headerStyle, isHeader: true),
          ],
        ),
        // Data rows
        ...rows.map((row) => pw.TableRow(
          children: [
            _tableCell(row.month, textStyle),
            _tableCell(row.period, textStyle),
            _tableCell(row.week, textStyle),
            _tableCell(row.lessonsCount.toString(), textStyle),
            _tableCell(row.content, textStyle),
            _tableCell(row.goals, textStyle),
            _tableCell(row.methods, textStyle),
            _tableCell(row.activities, textStyle),
            _tableCell(row.assessment, textStyle),
          ],
        )),
      ],
    );
  }

  static pw.Widget _tableCell(String text, pw.TextStyle style, {bool isHeader = false}) {
    return pw.Container(
      padding: const pw.EdgeInsets.all(4),
      alignment: pw.Alignment.center,
      child: pw.Text(
        text,
        style: style,
        textAlign: pw.TextAlign.center,
        textDirection: pw.TextDirection.rtl,
      ),
    );
  }

  static pw.Widget _buildFooter(int pageNum, int totalPages, pw.TextStyle style) {
    return pw.Row(
      mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
      children: [
        pw.Text('تم إنشاء هذه الخطة بواسطة تطبيق منشئ الخطط الفصلية', style: style),
        pw.Text(AppConstants.developerCredit, style: style),
        pw.Text('صفحة $pageNum من $totalPages', style: style),
      ],
    );
  }
}

// Fix for AppUtils reference
class AppUtils {
  static String generateFileName(String subject, String grade, String semester) {
    return 'خطة_${subject}_${grade}_${semester}.pdf';
  }
}
