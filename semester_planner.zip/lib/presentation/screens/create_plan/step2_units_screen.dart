import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:reorderables/reorderables.dart';
import '../../../core/utils/app_utils.dart';
import '../../../data/models/unit_model.dart';
import '../../../domain/entities/plan_entity.dart';
import '../../../domain/providers/plan_providers.dart';
import 'step3_lessons_screen.dart';

class Step2UnitsScreen extends ConsumerStatefulWidget {
  const Step2UnitsScreen({super.key});

  @override
  ConsumerState<Step2UnitsScreen> createState() => _Step2UnitsScreenState();
}

class _Step2UnitsScreenState extends ConsumerState<Step2UnitsScreen> {
  @override
  Widget build(BuildContext context) {
    final builderState = ref.watch(planBuilderProvider);
    final units = builderState.units;

    return Scaffold(
      appBar: AppBar(title: const Text('إدارة الوحدات')),
      body: Column(
        children: [
          Expanded(
            child: units.isEmpty
                ? _buildEmptyState()
                : _buildUnitsList(units),
          ),
          _buildBottomButtons(units),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showAddUnitDialog,
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.folder_open, size: 80, color: Colors.grey[400]),
          const SizedBox(height: 16),
          Text(
            'لا توجد وحدات',
            style: TextStyle(fontSize: 18, color: Colors.grey[600]),
          ),
          const SizedBox(height: 8),
          Text(
            'اضغط على الزر + لإضافة وحدة',
            style: TextStyle(fontSize: 14, color: Colors.grey[500]),
          ),
        ],
      ),
    );
  }

  Widget _buildUnitsList(List<UnitEntity> units) {
    return ReorderableColumn(
      padding: const EdgeInsets.all(16),
      onReorder: (oldIndex, newIndex) {
        final newUnits = [...units];
        final item = newUnits.removeAt(oldIndex);
        newUnits.insert(newIndex, item);
        ref.read(planBuilderProvider.notifier).reorderUnits(newUnits);
      },
      children: units.asMap().entries.map((entry) {
        final index = entry.key;
        final unit = entry.value;
        return Card(
          key: ValueKey(unit.unit.id ?? index),
          margin: const EdgeInsets.only(bottom: 12),
          child: ListTile(
            contentPadding: const EdgeInsets.all(16),
            leading: CircleAvatar(
              child: Text('${index + 1}'),
            ),
            title: Text(
              unit.unit.name,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            subtitle: Text('عدد الحصص: ${unit.unit.lessonsCount}'),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: const Icon(Icons.edit, color: Colors.blue),
                  onPressed: () => _showEditUnitDialog(index, unit),
                ),
                IconButton(
                  icon: const Icon(Icons.delete, color: Colors.red),
                  onPressed: () => _deleteUnit(index),
                ),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildBottomButtons(List<UnitEntity> units) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, -5),
          ),
        ],
      ),
      child: SafeArea(
        child: SizedBox(
          width: double.infinity,
          height: 50,
          child: ElevatedButton(
            onPressed: units.isEmpty
                ? null
                : () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const Step3LessonsScreen()),
                    ),
            child: const Text('التالي: إدارة الدروس', style: TextStyle(fontSize: 18)),
          ),
        ),
      ),
    );
  }

  void _showAddUnitDialog() {
    final nameController = TextEditingController();
    final countController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('إضافة وحدة جديدة'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameController,
              textDirection: TextDirection.rtl,
              decoration: const InputDecoration(labelText: 'اسم الوحدة'),
            ),
            TextField(
              controller: countController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'عدد الحصص'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            onPressed: () {
              if (nameController.text.isEmpty || countController.text.isEmpty) {
                AppUtils.showToast('يرجى ملء جميع الحقول', isError: true);
                return;
              }
              final unit = UnitEntity(
                unit: UnitModel(
                  planId: 0,
                  name: nameController.text,
                  lessonsCount: int.parse(countController.text),
                  orderIndex: ref.read(planBuilderProvider).units.length,
                ),
                lessons: [],
              );
              ref.read(planBuilderProvider.notifier).addUnit(unit);
              Navigator.pop(context);
            },
            child: const Text('إضافة'),
          ),
        ],
      ),
    );
  }

  void _showEditUnitDialog(int index, UnitEntity unitEntity) {
    final nameController = TextEditingController(text: unitEntity.unit.name);
    final countController = TextEditingController(text: unitEntity.unit.lessonsCount.toString());

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('تعديل الوحدة'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameController,
              textDirection: TextDirection.rtl,
              decoration: const InputDecoration(labelText: 'اسم الوحدة'),
            ),
            TextField(
              controller: countController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'عدد الحصص'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            onPressed: () {
              final updated = unitEntity.copyWith(
                unit: unitEntity.unit.copyWith(
                  name: nameController.text,
                  lessonsCount: int.parse(countController.text),
                ),
              );
              ref.read(planBuilderProvider.notifier).updateUnit(index, updated);
              Navigator.pop(context);
            },
            child: const Text('حفظ'),
          ),
        ],
      ),
    );
  }

  void _deleteUnit(int index) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('تأكيد الحذف'),
        content: const Text('هل أنت متأكد من حذف هذه الوحدة؟'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          TextButton(
            onPressed: () {
              ref.read(planBuilderProvider.notifier).removeUnit(index);
              Navigator.pop(context);
            },
            child: const Text('حذف', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }
}
