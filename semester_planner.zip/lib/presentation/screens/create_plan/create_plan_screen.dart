import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/utils/app_utils.dart';
import '../../../data/models/plan_model.dart';
import '../../../domain/providers/plan_providers.dart';
import 'step2_units_screen.dart';

class CreatePlanScreen extends ConsumerStatefulWidget {
  const CreatePlanScreen({super.key});

  @override
  ConsumerState<CreatePlanScreen> createState() => _CreatePlanScreenState();
}

class _CreatePlanScreenState extends ConsumerState<CreatePlanScreen> {
  final _formKey = GlobalKey<FormState>();
  final _schoolController = TextEditingController();
  final _teacherController = TextEditingController();
  final _subjectController = TextEditingController();
  final _gradeController = TextEditingController();
  final _semesterController = TextEditingController();
  final _yearController = TextEditingController();
  final _lessonsController = TextEditingController();
  DateTime? _startDate;
  DateTime? _endDate;

  @override
  void dispose() {
    _schoolController.dispose();
    _teacherController.dispose();
    _subjectController.dispose();
    _gradeController.dispose();
    _semesterController.dispose();
    _yearController.dispose();
    _lessonsController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إنشاء خطة جديدة')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _buildSectionTitle('البيانات الأساسية'),
            const SizedBox(height: 16),
            _buildTextField(_schoolController, 'اسم المدرسة', Icons.school),
            const SizedBox(height: 12),
            _buildTextField(_teacherController, 'اسم المعلم', Icons.person),
            const SizedBox(height: 12),
            _buildTextField(_subjectController, 'المادة', Icons.book),
            const SizedBox(height: 12),
            _buildTextField(_gradeController, 'الصف', Icons.class_),
            const SizedBox(height: 12),
            _buildTextField(_semesterController, 'الفصل الدراسي', Icons.calendar_today),
            const SizedBox(height: 12),
            _buildTextField(_yearController, 'العام الدراسي', Icons.date_range),
            const SizedBox(height: 12),
            _buildNumberField(_lessonsController, 'عدد الحصص الأسبوعية', Icons.schedule),
            const SizedBox(height: 16),
            _buildDatePickers(),
            const SizedBox(height: 32),
            SizedBox(
              height: 50,
              child: ElevatedButton(
                onPressed: _onNext,
                child: const Text('التالي', style: TextStyle(fontSize: 18)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      decoration: BoxDecoration(
        color: Theme.of(context).primaryColor.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
          color: Theme.of(context).primaryColor,
        ),
      ),
    );
  }

  Widget _buildTextField(TextEditingController controller, String label, IconData icon) {
    return TextFormField(
      controller: controller,
      textDirection: TextDirection.rtl,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon),
      ),
      validator: (value) {
        if (value == null || value.isEmpty) return 'هذا الحقل مطلوب';
        return null;
      },
    );
  }

  Widget _buildNumberField(TextEditingController controller, String label, IconData icon) {
    return TextFormField(
      controller: controller,
      keyboardType: TextInputType.number,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon),
      ),
      validator: (value) {
        if (value == null || value.isEmpty) return 'هذا الحقل مطلوب';
        if (int.tryParse(value) == null) return 'يجب إدخال رقم صحيح';
        return null;
      },
    );
  }

  Widget _buildDatePickers() {
    return Row(
      children: [
        Expanded(
          child: _buildDatePicker('تاريخ البداية', _startDate, (date) {
            setState(() => _startDate = date);
          }),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _buildDatePicker('تاريخ النهاية', _endDate, (date) {
            setState(() => _endDate = date);
          }),
        ),
      ],
    );
  }

  Widget _buildDatePicker(String label, DateTime? date, Function(DateTime) onSelect) {
    return InkWell(
      onTap: () async {
        final picked = await showDatePicker(
          context: context,
          initialDate: DateTime.now(),
          firstDate: DateTime(2020),
          lastDate: DateTime(2030),
        );
        if (picked != null) onSelect(picked);
      },
      child: InputDecorator(
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: const Icon(Icons.calendar_today),
        ),
        child: Text(
          date != null ? AppUtils.formatDate(date) : 'اختر التاريخ',
          textAlign: TextAlign.right,
        ),
      ),
    );
  }

  void _onNext() {
    if (!_formKey.currentState!.validate()) return;
    if (_startDate == null || _endDate == null) {
      AppUtils.showToast('يرجى اختيار تواريخ البداية والنهاية', isError: true);
      return;
    }

    final plan = PlanModel(
      schoolName: _schoolController.text,
      teacherName: _teacherController.text,
      subject: _subjectController.text,
      grade: _gradeController.text,
      semester: _semesterController.text,
      academicYear: _yearController.text,
      weeklyLessons: int.parse(_lessonsController.text),
      startDate: _startDate!.toIso8601String(),
      endDate: _endDate!.toIso8601String(),
      createdAt: DateTime.now().toIso8601String(),
      updatedAt: DateTime.now().toIso8601String(),
    );

    ref.read(planBuilderProvider.notifier).setPlan(plan);

    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const Step2UnitsScreen()),
    );
  }
}
