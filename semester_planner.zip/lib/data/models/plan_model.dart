class PlanModel {
  final int? id;
  final String schoolName;
  final String teacherName;
  final String subject;
  final String grade;
  final String semester;
  final String academicYear;
  final int weeklyLessons;
  final String startDate;
  final String endDate;
  final String createdAt;
  final String updatedAt;

  PlanModel({
    this.id,
    required this.schoolName,
    required this.teacherName,
    required this.subject,
    required this.grade,
    required this.semester,
    required this.academicYear,
    required this.weeklyLessons,
    required this.startDate,
    required this.endDate,
    required this.createdAt,
    required this.updatedAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'school_name': schoolName,
      'teacher_name': teacherName,
      'subject': subject,
      'grade': grade,
      'semester': semester,
      'academic_year': academicYear,
      'weekly_lessons': weeklyLessons,
      'start_date': startDate,
      'end_date': endDate,
      'created_at': createdAt,
      'updated_at': updatedAt,
    };
  }

  factory PlanModel.fromMap(Map<String, dynamic> map) {
    return PlanModel(
      id: map['id'] as int?,
      schoolName: map['school_name'] as String,
      teacherName: map['teacher_name'] as String,
      subject: map['subject'] as String,
      grade: map['grade'] as String,
      semester: map['semester'] as String,
      academicYear: map['academic_year'] as String,
      weeklyLessons: map['weekly_lessons'] as int,
      startDate: map['start_date'] as String,
      endDate: map['end_date'] as String,
      createdAt: map['created_at'] as String,
      updatedAt: map['updated_at'] as String,
    );
  }

  PlanModel copyWith({
    int? id,
    String? schoolName,
    String? teacherName,
    String? subject,
    String? grade,
    String? semester,
    String? academicYear,
    int? weeklyLessons,
    String? startDate,
    String? endDate,
    String? createdAt,
    String? updatedAt,
  }) {
    return PlanModel(
      id: id ?? this.id,
      schoolName: schoolName ?? this.schoolName,
      teacherName: teacherName ?? this.teacherName,
      subject: subject ?? this.subject,
      grade: grade ?? this.grade,
      semester: semester ?? this.semester,
      academicYear: academicYear ?? this.academicYear,
      weeklyLessons: weeklyLessons ?? this.weeklyLessons,
      startDate: startDate ?? this.startDate,
      endDate: endDate ?? this.endDate,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}
