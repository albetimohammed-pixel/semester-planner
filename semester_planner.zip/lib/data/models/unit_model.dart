class UnitModel {
  final int? id;
  final int planId;
  final String name;
  final int lessonsCount;
  final int orderIndex;

  UnitModel({
    this.id,
    required this.planId,
    required this.name,
    required this.lessonsCount,
    required this.orderIndex,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'plan_id': planId,
      'name': name,
      'lessons_count': lessonsCount,
      'order_index': orderIndex,
    };
  }

  factory UnitModel.fromMap(Map<String, dynamic> map) {
    return UnitModel(
      id: map['id'] as int?,
      planId: map['plan_id'] as int,
      name: map['name'] as String,
      lessonsCount: map['lessons_count'] as int,
      orderIndex: map['order_index'] as int,
    );
  }

  UnitModel copyWith({
    int? id,
    int? planId,
    String? name,
    int? lessonsCount,
    int? orderIndex,
  }) {
    return UnitModel(
      id: id ?? this.id,
      planId: planId ?? this.planId,
      name: name ?? this.name,
      lessonsCount: lessonsCount ?? this.lessonsCount,
      orderIndex: orderIndex ?? this.orderIndex,
    );
  }
}
