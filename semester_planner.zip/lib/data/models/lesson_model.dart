class LessonModel {
  final int? id;
  final int unitId;
  final String title;
  final int lessonsCount;
  final String goals;
  final int orderIndex;

  LessonModel({
    this.id,
    required this.unitId,
    required this.title,
    required this.lessonsCount,
    required this.goals,
    required this.orderIndex,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'unit_id': unitId,
      'title': title,
      'lessons_count': lessonsCount,
      'goals': goals,
      'order_index': orderIndex,
    };
  }

  factory LessonModel.fromMap(Map<String, dynamic> map) {
    return LessonModel(
      id: map['id'] as int?,
      unitId: map['unit_id'] as int,
      title: map['title'] as String,
      lessonsCount: map['lessons_count'] as int,
      goals: map['goals'] as String,
      orderIndex: map['order_index'] as int,
    );
  }

  LessonModel copyWith({
    int? id,
    int? unitId,
    String? title,
    int? lessonsCount,
    String? goals,
    int? orderIndex,
  }) {
    return LessonModel(
      id: id ?? this.id,
      unitId: unitId ?? this.unitId,
      title: title ?? this.title,
      lessonsCount: lessonsCount ?? this.lessonsCount,
      goals: goals ?? this.goals,
      orderIndex: orderIndex ?? this.orderIndex,
    );
  }
}
