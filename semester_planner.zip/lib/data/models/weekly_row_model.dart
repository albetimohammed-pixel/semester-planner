class WeeklyRowModel {
  final int? id;
  final int planId;
  final String month;
  final String period;
  final String week;
  final int lessonsCount;
  final String content;
  final String goals;
  final String methods;
  final String resources;
  final String activities;
  final String assessment;
  final int orderIndex;

  WeeklyRowModel({
    this.id,
    required this.planId,
    required this.month,
    required this.period,
    required this.week,
    required this.lessonsCount,
    required this.content,
    required this.goals,
    required this.methods,
    required this.resources,
    required this.activities,
    required this.assessment,
    required this.orderIndex,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'plan_id': planId,
      'month': month,
      'period': period,
      'week': week,
      'lessons_count': lessonsCount,
      'content': content,
      'goals': goals,
      'methods': methods,
      'resources': resources,
      'activities': activities,
      'assessment': assessment,
      'order_index': orderIndex,
    };
  }

  factory WeeklyRowModel.fromMap(Map<String, dynamic> map) {
    return WeeklyRowModel(
      id: map['id'] as int?,
      planId: map['plan_id'] as int,
      month: map['month'] as String,
      period: map['period'] as String,
      week: map['week'] as String,
      lessonsCount: map['lessons_count'] as int,
      content: map['content'] as String,
      goals: map['goals'] as String,
      methods: map['methods'] as String,
      resources: map['resources'] as String,
      activities: map['activities'] as String,
      assessment: map['assessment'] as String,
      orderIndex: map['order_index'] as int,
    );
  }

  WeeklyRowModel copyWith({
    int? id,
    int? planId,
    String? month,
    String? period,
    String? week,
    int? lessonsCount,
    String? content,
    String? goals,
    String? methods,
    String? resources,
    String? activities,
    String? assessment,
    int? orderIndex,
  }) {
    return WeeklyRowModel(
      id: id ?? this.id,
      planId: planId ?? this.planId,
      month: month ?? this.month,
      period: period ?? this.period,
      week: week ?? this.week,
      lessonsCount: lessonsCount ?? this.lessonsCount,
      content: content ?? this.content,
      goals: goals ?? this.goals,
      methods: methods ?? this.methods,
      resources: resources ?? this.resources,
      activities: activities ?? this.activities,
      assessment: assessment ?? this.assessment,
      orderIndex: orderIndex ?? this.orderIndex,
    );
  }
}
