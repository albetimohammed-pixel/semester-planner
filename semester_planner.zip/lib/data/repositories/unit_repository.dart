import 'package:sqflite/sqflite.dart';
import '../database/database_helper.dart';
import '../models/unit_model.dart';

class UnitRepository {
  final DatabaseHelper _dbHelper = DatabaseHelper.instance;

  Future<int> insertUnit(UnitModel unit) async {
    final db = await _dbHelper.database;
    return await db.insert('units', unit.toMap());
  }

  Future<List<UnitModel>> getUnitsByPlanId(int planId) async {
    final db = await _dbHelper.database;
    final maps = await db.query(
      'units',
      where: 'plan_id = ?',
      whereArgs: [planId],
      orderBy: 'order_index ASC',
    );
    return maps.map((e) => UnitModel.fromMap(e)).toList();
  }

  Future<int> updateUnit(UnitModel unit) async {
    final db = await _dbHelper.database;
    return await db.update(
      'units',
      unit.toMap(),
      where: 'id = ?',
      whereArgs: [unit.id],
    );
  }

  Future<int> deleteUnit(int id) async {
    final db = await _dbHelper.database;
    return await db.delete('units', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> reorderUnits(List<UnitModel> units) async {
    final db = await _dbHelper.database;
    await db.transaction((txn) async {
      for (int i = 0; i < units.length; i++) {
        await txn.update(
          'units',
          {'order_index': i},
          where: 'id = ?',
          whereArgs: [units[i].id],
        );
      }
    });
  }
}
