import 'package:sqflite/sqflite.dart';
import '../database/database_helper.dart';
import '../models/plan_model.dart';

class PlanRepository {
  final DatabaseHelper _dbHelper = DatabaseHelper.instance;

  Future<int> insertPlan(PlanModel plan) async {
    final db = await _dbHelper.database;
    return await db.insert('plans', plan.toMap());
  }

  Future<List<PlanModel>> getAllPlans() async {
    final db = await _dbHelper.database;
    final maps = await db.query('plans', orderBy: 'updated_at DESC');
    return maps.map((e) => PlanModel.fromMap(e)).toList();
  }

  Future<PlanModel?> getPlanById(int id) async {
    final db = await _dbHelper.database;
    final maps = await db.query('plans', where: 'id = ?', whereArgs: [id]);
    if (maps.isEmpty) return null;
    return PlanModel.fromMap(maps.first);
  }

  Future<int> updatePlan(PlanModel plan) async {
    final db = await _dbHelper.database;
    return await db.update(
      'plans',
      plan.toMap(),
      where: 'id = ?',
      whereArgs: [plan.id],
    );
  }

  Future<int> deletePlan(int id) async {
    final db = await _dbHelper.database;
    return await db.delete('plans', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<PlanModel>> searchPlans(String query) async {
    final db = await _dbHelper.database;
    final maps = await db.query(
      'plans',
      where: 'subject LIKE ? OR teacher_name LIKE ? OR school_name LIKE ?',
      whereArgs: ['%$query%', '%$query%', '%$query%'],
      orderBy: 'updated_at DESC',
    );
    return maps.map((e) => PlanModel.fromMap(e)).toList();
  }
}
