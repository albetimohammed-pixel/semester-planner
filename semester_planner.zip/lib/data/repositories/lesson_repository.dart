import 'package:sqflite/sqflite.dart';
import '../database/database_helper.dart';
import '../models/lesson_model.dart';

class LessonRepository {
  final DatabaseHelper _dbHelper = DatabaseHelper.instance;

  Future<int> insertLesson(LessonModel lesson) async {
    final db = await _dbHelper.database;
    return await db.insert('lessons', lesson.toMap());
  }

  Future<List<LessonModel>> getLessonsByUnitId(int unitId) async {
    final db = await _dbHelper.database;
    final maps = await db.query(
      'lessons',
      where: 'unit_id = ?',
      whereArgs: [unitId],
      orderBy: 'order_index ASC',
    );
    return maps.map((e) => LessonModel.fromMap(e)).toList();
  }

  Future<int> updateLesson(LessonModel lesson) async {
    final db = await _dbHelper.database;
    return await db.update(
      'lessons',
      lesson.toMap(),
      where: 'id = ?',
      whereArgs: [lesson.id],
    );
  }

  Future<int> deleteLesson(int id) async {
    final db = await _dbHelper.database;
    return await db.delete('lessons', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> reorderLessons(List<LessonModel> lessons) async {
    final db = await _dbHelper.database;
    await db.transaction((txn) async {
      for (int i = 0; i < lessons.length; i++) {
        await txn.update(
          'lessons',
          {'order_index': i},
          where: 'id = ?',
          whereArgs: [lessons[i].id],
        );
      }
    });
  }
}
