import 'package:sqflite/sqflite.dart';
import '../database/database_helper.dart';
import '../models/weekly_row_model.dart';

class WeeklyRowRepository {
  final DatabaseHelper _dbHelper = DatabaseHelper.instance;

  Future<int> insertRow(WeeklyRowModel row) async {
    final db = await _dbHelper.database;
    return await db.insert('weekly_rows', row.toMap());
  }

  Future<List<WeeklyRowModel>> getRowsByPlanId(int planId) async {
    final db = await _dbHelper.database;
    final maps = await db.query(
      'weekly_rows',
      where: 'plan_id = ?',
      whereArgs: [planId],
      orderBy: 'order_index ASC',
    );
    return maps.map((e) => WeeklyRowModel.fromMap(e)).toList();
  }

  Future<int> updateRow(WeeklyRowModel row) async {
    final db = await _dbHelper.database;
    return await db.update(
      'weekly_rows',
      row.toMap(),
      where: 'id = ?',
      whereArgs: [row.id],
    );
  }

  Future<int> deleteRow(int id) async {
    final db = await _dbHelper.database;
    return await db.delete('weekly_rows', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> reorderRows(List<WeeklyRowModel> rows) async {
    final db = await _dbHelper.database;
    await db.transaction((txn) async {
      for (int i = 0; i < rows.length; i++) {
        await txn.update(
          'weekly_rows',
          {'order_index': i},
          where: 'id = ?',
          whereArgs: [rows[i].id],
        );
      }
    });
  }

  Future<void> deleteAllRowsByPlanId(int planId) async {
    final db = await _dbHelper.database;
    await db.delete('weekly_rows', where: 'plan_id = ?', whereArgs: [planId]);
  }
}
