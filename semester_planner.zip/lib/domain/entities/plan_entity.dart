import '../../data/models/plan_model.dart';
import '../../data/models/unit_model.dart';
import '../../data/models/lesson_model.dart';
import '../../data/models/weekly_row_model.dart';

class PlanEntity {
  final PlanModel plan;
  final List<UnitEntity> units;
  final List<WeeklyRowModel> weeklyRows;

  PlanEntity({
    required this.plan,
    required this.units,
    required this.weeklyRows,
  });
}

class UnitEntity {
  final UnitModel unit;
  final List<LessonModel> lessons;

  UnitEntity({
    required this.unit,
    required this.lessons,
  });
}
