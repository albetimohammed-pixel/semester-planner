import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/models/plan_model.dart';
import '../../data/models/unit_model.dart';
import '../../data/models/lesson_model.dart';
import '../../data/models/weekly_row_model.dart';
import '../../data/repositories/plan_repository.dart';
import '../../data/repositories/unit_repository.dart';
import '../../data/repositories/lesson_repository.dart';
import '../../data/repositories/weekly_row_repository.dart';
import '../entities/plan_entity.dart';

// Repositories
final planRepositoryProvider = Provider((ref) => PlanRepository());
final unitRepositoryProvider = Provider((ref) => UnitRepository());
final lessonRepositoryProvider = Provider((ref) => LessonRepository());
final weeklyRowRepositoryProvider = Provider((ref) => WeeklyRowRepository());

// All Plans
final allPlansProvider = FutureProvider<List<PlanModel>>((ref) async {
  final repo = ref.watch(planRepositoryProvider);
  return await repo.getAllPlans();
});

// Search Plans
final searchPlansProvider = FutureProvider.family<List<PlanModel>, String>((ref, query) async {
  final repo = ref.watch(planRepositoryProvider);
  return await repo.searchPlans(query);
});

// Plan Detail
final planDetailProvider = FutureProvider.family<PlanEntity?, int>((ref, planId) async {
  final planRepo = ref.watch(planRepositoryProvider);
  final unitRepo = ref.watch(unitRepositoryProvider);
  final lessonRepo = ref.watch(lessonRepositoryProvider);
  final rowRepo = ref.watch(weeklyRowRepositoryProvider);

  final plan = await planRepo.getPlanById(planId);
  if (plan == null) return null;

  final units = await unitRepo.getUnitsByPlanId(planId);
  final unitEntities = <UnitEntity>[];

  for (final unit in units) {
    final lessons = await lessonRepo.getLessonsByUnitId(unit.id!);
    unitEntities.add(UnitEntity(unit: unit, lessons: lessons));
  }

  final rows = await rowRepo.getRowsByPlanId(planId);

  return PlanEntity(plan: plan, units: unitEntities, weeklyRows: rows);
});

// Current Plan Builder State
class PlanBuilderState {
  final PlanModel? plan;
  final List<UnitEntity> units;
  final List<WeeklyRowModel> weeklyRows;

  PlanBuilderState({
    this.plan,
    this.units = const [],
    this.weeklyRows = const [],
  });

  PlanBuilderState copyWith({
    PlanModel? plan,
    List<UnitEntity>? units,
    List<WeeklyRowModel>? weeklyRows,
  }) {
    return PlanBuilderState(
      plan: plan ?? this.plan,
      units: units ?? this.units,
      weeklyRows: weeklyRows ?? this.weeklyRows,
    );
  }
}

class PlanBuilderNotifier extends StateNotifier<PlanBuilderState> {
  PlanBuilderNotifier() : super(PlanBuilderState());

  void setPlan(PlanModel plan) {
    state = state.copyWith(plan: plan);
  }

  void setUnits(List<UnitEntity> units) {
    state = state.copyWith(units: units);
  }

  void addUnit(UnitEntity unit) {
    state = state.copyWith(units: [...state.units, unit]);
  }

  void updateUnit(int index, UnitEntity unit) {
    final newUnits = [...state.units];
    newUnits[index] = unit;
    state = state.copyWith(units: newUnits);
  }

  void removeUnit(int index) {
    final newUnits = [...state.units];
    newUnits.removeAt(index);
    state = state.copyWith(units: newUnits);
  }

  void reorderUnits(List<UnitEntity> units) {
    state = state.copyWith(units: units);
  }

  void setWeeklyRows(List<WeeklyRowModel> rows) {
    state = state.copyWith(weeklyRows: rows);
  }

  void addWeeklyRow(WeeklyRowModel row) {
    state = state.copyWith(weeklyRows: [...state.weeklyRows, row]);
  }

  void updateWeeklyRow(int index, WeeklyRowModel row) {
    final newRows = [...state.weeklyRows];
    newRows[index] = row;
    state = state.copyWith(weeklyRows: newRows);
  }

  void removeWeeklyRow(int index) {
    final newRows = [...state.weeklyRows];
    newRows.removeAt(index);
    state = state.copyWith(weeklyRows: newRows);
  }

  void reorderWeeklyRows(List<WeeklyRowModel> rows) {
    state = state.copyWith(weeklyRows: rows);
  }

  void clear() {
    state = PlanBuilderState();
  }
}

final planBuilderProvider = StateNotifierProvider<PlanBuilderNotifier, PlanBuilderState>((ref) {
  return PlanBuilderNotifier();
});

// Selected Libraries State
class LibrariesState {
  final List<String> selectedMethods;
  final List<String> selectedResources;
  final List<String> selectedActivities;
  final List<String> selectedAssessments;

  LibrariesState({
    this.selectedMethods = const [],
    this.selectedResources = const [],
    this.selectedActivities = const [],
    this.selectedAssessments = const [],
  });

  LibrariesState copyWith({
    List<String>? selectedMethods,
    List<String>? selectedResources,
    List<String>? selectedActivities,
    List<String>? selectedAssessments,
  }) {
    return LibrariesState(
      selectedMethods: selectedMethods ?? this.selectedMethods,
      selectedResources: selectedResources ?? this.selectedResources,
      selectedActivities: selectedActivities ?? this.selectedActivities,
      selectedAssessments: selectedAssessments ?? this.selectedAssessments,
    );
  }
}

class LibrariesNotifier extends StateNotifier<LibrariesState> {
  LibrariesNotifier() : super(LibrariesState());

  void toggleMethod(String method) {
    final methods = [...state.selectedMethods];
    if (methods.contains(method)) {
      methods.remove(method);
    } else {
      methods.add(method);
    }
    state = state.copyWith(selectedMethods: methods);
  }

  void toggleResource(String resource) {
    final resources = [...state.selectedResources];
    if (resources.contains(resource)) {
      resources.remove(resource);
    } else {
      resources.add(resource);
    }
    state = state.copyWith(selectedResources: resources);
  }

  void toggleActivity(String activity) {
    final activities = [...state.selectedActivities];
    if (activities.contains(activity)) {
      activities.remove(activity);
    } else {
      activities.add(activity);
    }
    state = state.copyWith(selectedActivities: activities);
  }

  void toggleAssessment(String assessment) {
    final assessments = [...state.selectedAssessments];
    if (assessments.contains(assessment)) {
      assessments.remove(assessment);
    } else {
      assessments.add(assessment);
    }
    state = state.copyWith(selectedAssessments: assessments);
  }

  void clear() {
    state = LibrariesState();
  }
}

final librariesProvider = StateNotifierProvider<LibrariesNotifier, LibrariesState>((ref) {
  return LibrariesNotifier();
});
