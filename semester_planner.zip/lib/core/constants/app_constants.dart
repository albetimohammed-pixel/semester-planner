class AppConstants {
  static const String appName = 'منشئ الخطط الفصلية';
  static const String developerName = 'أنور أحمد البيتي';
  static const String developerCredit = 'تصميم وبرمجة: أنور أحمد البيتي';
  static const String folderName = 'الخطط الفصلية';
  static const String dbName = 'semester_planner.db';
  static const String backupExtension = '.spbackup';

  static const List<String> teachingMethods = [
    'الحوار',
    'المناقشة',
    'الاستنتاج',
    'الاستقراء',
    'العصف الذهني',
    'التعلم التعاوني',
    'حل المشكلات',
  ];

  static const List<String> educationalResources = [
    'الكتاب المدرسي',
    'السبورة',
    'الأقلام الملونة',
    'لوحة تعليمية',
    'شاشة تعليمية',
    'جهاز عرض',
    'وسائل أخرى',
  ];

  static const List<String> activities = [
    'واجبات منزلية',
    'مشاهدة فيديوهات تعليمية',
    'بحوث علمية',
    'إذاعة مدرسية',
    'مسابقات تعليمية',
    'أنشطة جماعية',
    'أوراق عمل',
  ];

  static const List<String> assessments = [
    'التقويم البنائي',
    'الاختبارات التحريرية',
    'الاختبارات الشفوية',
    'أوراق العمل',
    'الواجبات المنزلية',
    'الملاحظة المباشرة',
  ];
}
