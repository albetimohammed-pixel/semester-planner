package com.example.semester_planner

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
